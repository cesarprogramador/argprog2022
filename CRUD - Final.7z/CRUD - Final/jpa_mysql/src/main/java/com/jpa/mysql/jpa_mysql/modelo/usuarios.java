package com.jpa.mysql.jpa_mysql.modelo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class usuarios {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int idusuario;
    private String usuario;
    private String password;
    private String email;
    private boolean eliminado;

    public usuarios() {
    }

    public usuarios(int idusuario, String usuario, String password, String email) {
        this.idusuario = idusuario;
        this.usuario = usuario;
        this.password = password;
        this.email = email;
    }

    public usuarios(String usuario, String password, String email, boolean eliminado) {
        this.usuario = usuario;
        this.password = password;
        this.email = email;
        this.eliminado=eliminado;
    }

    public int getIdusuario() {
        return this.idusuario;
    }

    public void setIdusuario(int idusuario) {
        this.idusuario = idusuario;
    }

    public String getUsuario() {
        return this.usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isEliminado() {
        return this.eliminado;
    }

    public boolean getEliminado() {
        return this.eliminado;
    }

    public void setEliminado(boolean eliminado) {
        this.eliminado = eliminado;
    }
}
