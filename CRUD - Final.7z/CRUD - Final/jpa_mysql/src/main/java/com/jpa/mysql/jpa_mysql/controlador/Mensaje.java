package com.jpa.mysql.jpa_mysql.controlador;

public class Mensaje {
    private String msn="";

    public Mensaje() {
    }

    public Mensaje(String msn) {
        this.msn = msn;
    }

    public String getMsn() {
        return this.msn;
    }

    public void setMsn(String msn) {
        this.msn = msn;
    }
}
