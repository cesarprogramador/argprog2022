package com.jpa.mysql.jpa_mysql.controlador;

import com.jpa.mysql.jpa_mysql.modelo.usuarios;
import com.jpa.mysql.jpa_mysql.modelo.usuarioscrud;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/crudusuario")
public class controladorcrud {
    
    @Autowired
    private usuarioscrud userRepository;

    @GetMapping("/all")
    @ResponseBody
    public Iterable<usuarios> allUsers(){
        return userRepository.allUsers();
    }
    
    @GetMapping("/usuarioxid")
    @ResponseBody
    public usuarios oneUsers(@RequestParam int idusuario){
        return userRepository.findById(idusuario);
    }

    @GetMapping("/selectusuarioxid")
    public ResponseEntity<usuarios> selectOneUsers(@RequestParam int id){
        if (id<0) return new ResponseEntity(new Mensaje("Debe de seleccionar un usuario"), HttpStatus.BAD_REQUEST);
      
        usuarios usu=this.userRepository.findById(id);

        return new ResponseEntity(usu, HttpStatus.OK);
    }

    private boolean exiteUsuarioxid(int idusuario){
        return userRepository.existsById(idusuario);
    }
    
    private boolean exiteUsuarioxNombrexPasword(String usuario, String password){
        if (userRepository.exiteUsuarioxNombrexPasword(usuario, password)>0) return true;
        else return false;
    }

    @PostMapping("/add")
    @ResponseBody
    public String addNewUser(@RequestParam String usuario,
    @RequestParam String password,
    @RequestParam String email){
        usuarios usu=new usuarios();
        usu.setUsuario(usuario);
        usu.setPassword(password);
        usu.setEmail(email);
        userRepository.save(usu);
        return "Usuario agregado!!!";
    }

    @PostMapping("/addusu")
    public ResponseEntity<?> addUser(@RequestBody usuarios _usu){
        if (_usu.getUsuario()==null || _usu.getUsuario().length()<=0) return new ResponseEntity(new Mensaje("Debe de ingresar un nombre de usuario"), HttpStatus.BAD_REQUEST);
        if (_usu.getPassword()==null ||_usu.getPassword().length()<=0) return new ResponseEntity(new Mensaje("Debe de ingresar un password de usuario"), HttpStatus.BAD_REQUEST);
        if (_usu.getEmail()==null ||_usu.getEmail().length()<=0) return new ResponseEntity(new Mensaje("Debe de ingresar un email de usuario"), HttpStatus.BAD_REQUEST);
        if (exiteUsuarioxNombrexPasword(_usu.getUsuario(),_usu.getPassword())==true) return new ResponseEntity(new Mensaje("El usuario ya existe, ingrese otro usuario"), HttpStatus.BAD_REQUEST);
    
        usuarios usu=new usuarios(_usu.getUsuario(),_usu.getPassword(),_usu.getEmail(),false);
        userRepository.save(usu);

        return new ResponseEntity(new Mensaje("Usuario generado"), HttpStatus.OK);
    }

    @DeleteMapping("/delete")
    @ResponseBody
    public String deleteUserFisico(@RequestParam int idusuario){
        userRepository.deleteById(idusuario);
        return "Usuario eliminado!!!";
    }

    @DeleteMapping("/deleteusu")
    public ResponseEntity<?> deleteUser(@RequestParam int id){
        if (id<0) return new ResponseEntity(new Mensaje("Debe de seleccionar un usuario"), HttpStatus.BAD_REQUEST);
      
        usuarios usu=this.userRepository.findById(id);
    
        usu.setEliminado(true);
    
        userRepository.save(usu);

        return new ResponseEntity(new Mensaje("Usuario eliminado"), HttpStatus.OK);
    }

    @PutMapping("/update")
    @ResponseBody
    public String updateUser(@RequestParam int idusuario,
    @RequestParam String usuario,
    @RequestParam String password,
    @RequestParam String email){
        usuarios usu=this.userRepository.findById(idusuario);
        usu.setUsuario(usuario);
        usu.setPassword(password);
        usu.setEmail(email);
        userRepository.save(usu);
        return "Usuario modificado!!!";
    }

    @PutMapping("/updateusu")
    public ResponseEntity<?> updateUser(@RequestBody usuarios _usu){
        if (exiteUsuarioxid(_usu.getIdusuario())==false) return new ResponseEntity(new Mensaje("El usuario no existe"), HttpStatus.NOT_FOUND);
        if (_usu.getUsuario()==null || _usu.getUsuario().length()<=0) return new ResponseEntity(new Mensaje("Debe de ingresar un nombre de usuario"), HttpStatus.BAD_REQUEST);
        if (_usu.getPassword()==null ||_usu.getPassword().length()<=0) return new ResponseEntity(new Mensaje("Debe de ingresar un password de usuario"), HttpStatus.BAD_REQUEST);
        if (_usu.getEmail()==null ||_usu.getEmail().length()<=0) return new ResponseEntity(new Mensaje("Debe de ingresar un email de usuario"), HttpStatus.BAD_REQUEST);
        if (exiteUsuarioxNombrexPasword(_usu.getUsuario(),_usu.getPassword())==true) return new ResponseEntity(new Mensaje("El usuario ya existe"), HttpStatus.BAD_REQUEST);
      
        usuarios usu=this.userRepository.findById(_usu.getIdusuario());
    
        usu.setUsuario(_usu.getUsuario());
        usu.setPassword(_usu.getPassword());
        usu.setEmail(_usu.getEmail());
        usu.setEliminado(_usu.getEliminado());
    
        userRepository.save(usu);

        return new ResponseEntity(new Mensaje("Usuario modificado "+_usu.getIdusuario()), HttpStatus.OK);
    }
}
