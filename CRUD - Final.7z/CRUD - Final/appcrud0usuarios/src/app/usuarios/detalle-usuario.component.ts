import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Usuarios } from '../models/usuarios';
import { UsuarioService } from '../service/usuario.service';

@Component({
  selector: 'app-detalle-usuario',
  templateUrl: './detalle-usuario.component.html',
  styleUrls: ['./detalle-usuario.component.css']
})
export class DetalleUsuarioComponent implements OnInit {
  _usuario: Usuarios=new Usuarios("","","");

  constructor(private usuarioService: UsuarioService,
    private actRouter:ActivatedRoute,
    private toastr: ToastrService,
    private router: Router) { }

  ngOnInit(): void {
    const id=this.actRouter.snapshot.params['id'];

    console.log(id);
    
    this.usuarioService.getUserDetailxId(id).subscribe(
      data=>{
        this._usuario=data;
       },
      err => {
        this.toastr.error(err.error.mesaje, 'Fail!', {
          timeOut: 3000,
        });

        this.router.navigate(['/']);
      }
      );
  }
}
